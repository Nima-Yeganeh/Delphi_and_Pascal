﻿
//======================
//Privatbank 2017©
// Generic POS Driver WebSoket client reference C# script
//=======================


using System;
using System.Text;
using System.Net.WebSockets;
using System.Threading;
using System.Linq;
using System.Threading.Tasks;

namespace WebSocketClient
{

    class WsClient
    {
        private string jsonStr, url;
        byte[] array;
        ClientWebSocket ws = new ClientWebSocket();

        public WsClient(string url, string jsonStr)
        {
            this.url = url;
            this.jsonStr = jsonStr;
            array = Encoding.ASCII.GetBytes(jsonStr);
        }

        public async Task<bool> conn()
        {
            try
            {
                await ws.ConnectAsync(new Uri(url), CancellationToken.None);
                Console.WriteLine(ws.State +": "+ url);
                if (ws.State.ToString() == "Open") return true;
                else return false;

            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.Message);
                return false;
            }
        }



        public async Task<bool> processMsg()
        {
            ArraySegment<byte> buffer = new ArraySegment<byte>(array);

            byte[] b = new byte[1024];

            ArraySegment<byte> answ = new ArraySegment<byte>(b);
//https://docs.microsoft.com/ru-ru/dotnet/api/system.arraysegment-1?view=netframework-4.8
//ArraySegment - Определяет границы фрагмента одномерного массива.

            try
            {
                await ws.SendAsync(buffer, WebSocketMessageType.Text, true, CancellationToken.None);
//https://docs.microsoft.com/ru-ru/dotnet/api/system.net.websockets.websocketmessagetype?view=netframework-4.8
//WebSocketMessageType.Text == 0
            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.Message);
                return false;
            }

            try
            {
                WebSocketReceiveResult res = await ws.ReceiveAsync(answ, CancellationToken.None);
                string value = Encoding.ASCII.GetString(answ.Array.Where(x => x > 0x00).ToArray());
                Console.WriteLine("Answer: " + value);
            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.Message);
                return false;

            }
            return true;

        }

        public async void closeConn(WebSocketCloseStatus wcs, string msg)
        {
            try
            {
                await ws.CloseAsync(wcs, msg, CancellationToken.None);
            }
            catch (Exception exc)
            {
                Console.WriteLine(exc.Message);

            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string jsonStr = "{\"method\":\"GetTerminalInfo\",\"step\":0}";// method for example
            string url = "ws://localhost:3000/echo";

            WsClient c = new WsClient(url, jsonStr);

            var task = c.conn();
            task.Wait();
            if (!task.Result)
            {
                Console.WriteLine("Connection error!");
                c.closeConn(WebSocketCloseStatus.ProtocolError, "Forcibly closing!");
                return;
            }
            task = c.processMsg();
            task.Wait();
            if (!task.Result)
            {
                Console.WriteLine("Communication error!");
                c.closeConn(WebSocketCloseStatus.ProtocolError, "Forcibly closing!");
                return;
            }
            c.closeConn(WebSocketCloseStatus.NormalClosure, "Normal Closure");

            Console.WriteLine("\nPress key to exit...");
            Console.ReadKey();

        }

    }
}
